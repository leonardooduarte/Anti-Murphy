# Patch AM17

Base: ZIP do complemento AM04/AM10, commit 3e4bf47, extraído sem executar.
Rode `python APLICAR_PATCH_AM17.py "pasta_base/ANTI_MURPHY_FINAL_2026" "nova_pasta_AM17"`.
O aplicador verifica hashes e cria uma pasta nova. A origem é preservada.
O ZIP do patch contém o overlay com as evidências binárias; o arquivo .patch
é a representação textual. Se baixou o ZIP completo, não precisa deste patch.
