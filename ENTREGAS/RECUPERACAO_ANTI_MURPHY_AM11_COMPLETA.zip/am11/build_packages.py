from pathlib import Path
import json,hashlib,shutil,zipfile,difflib
r=Path('/workspace/work/am11');app=r/'app';base=Path('/workspace/work/audit/reconstructed/ANTI_MURPHY_FINAL_2026');stage=r/'staging';project=stage/'ANTI_MURPHY_FINAL_2026';out=r/'packages-staged'
assert not stage.exists();shutil.copytree(base,project);out.mkdir()
changed=[]
for p in base.rglob('*'):
 if p.is_file():
  n=p.relative_to(base)
  if n.parts[0]!='workspace' and (app/n).read_bytes()!=p.read_bytes():changed.append(str(n))
added=['simulation/numeric.py','tests/test_am11_numeric_precision.py','tests/test_am11_consumers.py','tests/test_am11_review_regressions.py','tests/test_am11_display.py','RELATORIO_AM11_2026.md','CONTINUIDADE_AM11_2026.md','LEIA_AM11_2026.md','VERSAO_AM11.json']
added += [str(p.relative_to(app)) for p in (app/'docs/AM11').rglob('*') if p.is_file()]
for n in changed+added:
 p=project/n;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(app/n,p)
# Make included reproduction scripts portable inside the released project.
for n in ['reproduce_before.py','small_browser.py','actual_http_browser.py']:
 p=project/'docs/AM11/evidencias'/n;s=p.read_text()
 if n=='reproduce_before.py':s=s.replace('import json\n',"import json\nfrom pathlib import Path\nimport sys\nsys.path.insert(0, str(Path(__file__).resolve().parents[3]))\n",1)
 else:
  s=s.replace('from pathlib import Path\n',"from pathlib import Path\nimport sys\nsys.path.insert(0, str(Path(__file__).resolve().parents[3]))\n",1)
  s=s.replace("Path('/workspace/work/am11')", "Path(__file__).resolve().parent")
  s=s.replace("Path('/workspace/work/audit/actual-http')", "Path(__file__).resolve().parent/'capturas_http'")
 p.write_text(s)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
basehash={str(p.relative_to(base)):sha(p) for p in base.rglob('*') if p.is_file()}
targethash={str(p.relative_to(project)):sha(p) for p in project.rglob('*') if p.is_file()}
assert all(targethash[n]==h for n,h in basehash.items() if n.startswith('workspace/'))
assert all(targethash[n]==h for n,h in basehash.items() if n.startswith('atelier/web/') and n not in ['atelier/web/app.js','atelier/web/engineering_charts.js'])
assert not any('cache' in Path(n).parts or n.endswith('.pyc') for n in targethash)
manifest={'version':'AM11-2026.1','base_sha256':'b2e0b234a275432523698836bda0f596d7110ff4d264ae6ed6fb197a96a81419','base_files':basehash,'target_files':targethash,'changed':sorted(changed),'added':sorted(added)}
patchroot=r/'patch-staging';patchroot.mkdir();files=patchroot/'arquivos';files.mkdir()
diff=[]
for n in sorted(changed+added):
 src=project/n;dst=files/n;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dst)
 try:
  old=(base/n).read_text().splitlines(keepends=True) if (base/n).exists() else []
  new=src.read_text().splitlines(keepends=True)
  # XML/JSON evidence are plain text; PNG remains in overlay with verified SHA.
  if old and not old[-1].endswith('\n'):old[-1]+='\n'
  if new and not new[-1].endswith('\n'):new[-1]+='\n'
  diff.extend(difflib.unified_diff(old,new,fromfile='a/'+n if old else '/dev/null',tofile='b/'+n))
 except UnicodeDecodeError:diff.append('# Arquivo binário incluído no overlay: '+n+'\n')
(patchroot/'AM11.patch').write_text(''.join(diff))
(patchroot/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
script='''"""Apply AM11 to a fresh AM01-AM06 extraction, always creating a NEW folder."""
from pathlib import Path
import argparse,hashlib,json,shutil,sys

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('base',type=Path);parser.add_argument('output',type=Path)
 args=parser.parse_args();source=args.base.resolve();target=args.output.resolve();root=Path(__file__).resolve().parent
 manifest=json.loads((root/'manifest.json').read_text('utf-8'))
 if source==target or source in target.parents or target.exists():
  parser.error('Escolha uma pasta NOVA fora da base; nada foi alterado.')
 for name,expected in manifest['base_files'].items():
  p=source/name
  if not p.is_file() or digest(p)!=expected:parser.error('Base diferente da extracao original em '+name+'; nada foi alterado.')
 for name in manifest['added']:
  if (source/name).exists():parser.error('Arquivo novo ja existe na base: '+name)
 for name in manifest['changed']+manifest['added']:
  p=root/'arquivos'/name
  if not p.is_file() or digest(p)!=manifest['target_files'][name]:parser.error('Patch incompleto/corrompido: '+name)
 shutil.copytree(source,target)
 for name in manifest['changed']+manifest['added']:
  dest=target/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'arquivos'/name,dest)
 for name,expected in manifest['target_files'].items():
  if digest(target/name)!=expected:raise RuntimeError('Falha na verificacao de '+name)
 print('AM11 aplicado e verificado. Base original preservada. Nova pasta:',target)
if __name__=='__main__':main()
'''
(patchroot/'APLICAR_PATCH_AM11.py').write_text(script)
(patchroot/'LEIA_PATCH.md').write_text('''# Patch AM11-2026.1

O ZIP completo ja contem as correcoes; este patch e alternativa reproduzivel.
Extraia a base AM01-AM06 em pasta NOVA e NAO a execute antes de aplicar o patch.

```text
python APLICAR_PATCH_AM11.py "C:\\projetos\\base\\ANTI_MURPHY_FINAL_2026" "C:\\projetos\\ANTI_MURPHY_AM11"
```

A base nunca e sobrescrita. O script verifica hashes de todos os arquivos-base recebidos e cria nova pasta, aplicando o overlay verificado. Se voce editou projetos locais, mantenha-os em backup e use uma extracao limpa para aplicar. AM11.patch serve para revisao textual; o overlay tambem inclui a evidencia binaria. Manifesto contem hashes-base e alvo. Nenhum patch em AM05 ou demais achados foi aplicado.
''')
for name,folder in [('ANTI_MURPHY_AM11_COMPLETO_2026.zip',stage),('ANTI_MURPHY_PATCH_AM11_2026.zip',patchroot)]:
 with zipfile.ZipFile(out/name,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for p in sorted(folder.rglob('*')):
   if p.is_file():z.write(p,p.relative_to(folder))
for name in ['RELATORIO_AM11_2026.md','CONTINUIDADE_AM11_2026.md']:
 shutil.copy2(project/name,out/name)
shutil.copy2(patchroot/'AM11.patch',out/'AM11.patch')
(r/'release-manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
print(json.dumps({'project_files':len(targethash),'changed':len(changed),'added':len(added),'workspace_preserved':True,'packages':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in out.iterdir() if p.is_file()}},indent=2))
