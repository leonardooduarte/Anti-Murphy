# Revisão independente do patch AM-11

Revisão somente leitura da produção; comparei a base auditada com `/workspace/work/am11/app`. Testes próprios limitados a `tests/test_am11_review_regressions.py`.

## Achados reproduzidos enviados ao responsável

1. **Produto intermediário subnormal não nulo** em `simulation.numeric.product_ratio`: o fallback inicial só detectava zero/infinito. `product_ratio([1e-160,1e-160],[1e-320])` devolvia `1.0`, mas referência independente `Decimal.from_float` dá `1.000011132941258`. É perda por arredondamento subnormal intermediário, apesar de resposta final representável. Recomendação: detectar produtos intermediários subnormais e usar fallback Decimal, sem elevar fator/tempo a mínimo artificial.
2. **Overflow intermediário de percentual**, `simulation.decision_council._safe_pct`: `_safe_pct(1e308,1e308)` devolvia infinito, quando referência é100. Recomendei razão antes da escala e validação explícita de resultados realmente não representáveis; preservar sinal de ganhos negativos.
3. **Compatibilidade com `precise:null`**: `numeric.metric` assumia dict para toda chave `precise` presente, mas `_summary` pode conservar `None` para resultados antigos/inviáveis. Recomendei tratar null como campo ausente e usar a chave de compatibilidade.

Casos independentes adicionados: produto subnormal com referência Decimal80dígitos; percentuais positivos/negativos enormes com resposta100; percentual fora do float que deve dar erro explícito; JSON legado com `precise:null`.

## Observações sem bloqueio demonstrado

- Custos/atrasos/filas de apresentação continuam arredondados, enquanto `precise` e campos novos conservam entradas para comparações. O acréscimo mantém contratos existentes e torna mudança de centavos no benefício econômico legítima; relatório deve explicar diferença entre subtrair custos já arredondados e arredondar apenas o resultado final.
- A comparação arquivada recebe métricas precisas sem corrigir a omissão de investimento AM-08, o que mantém o escopo AM-11.
- Políticas explícitas de comparação (.005h, centavos, epsilons da dominância) não foram automaticamente removidas junto com os pisos físicos. São contratos de decisão distintos.
- A soma e os produtos ordinários de custo ainda merecem atenção para underflow positivo fora da faixa float; enviei ao responsável como caso de representação extrema, sem alegar ocorrência no cenário oficial.
- Não vi reescrita de DES, mudanças de identidade ou correções disfarçadas de AM-05 neste diff.

Validação final dos testes próprios deve ser registrada após o responsável aplicar os ajustes. Não alterei código de produção.
