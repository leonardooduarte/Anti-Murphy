# AM-11 — revisão e implementação de consumidores numéricos

Base comparada: reconstrução AM-01 a AM-06 preservada em `audit/reconstructed`. Código alterado somente na cópia de trabalho `am11/app`.

## Arquivos desta revisão

- `simulation/metrics.py`: `compare_results`, `murphy_score`, `fingerprint`.
- `simulation/advanced.py`: consumidores de métricas em sensibilidade, ruptura de demanda/ausência, recuperação e Monte Carlo.
- `simulation/innovation.py`: consumidores de métricas em Stress/Goal e `finance_lens`.
- `tests/test_am11_consumers.py`: 19 casos novos independentes de consumidores.

Usam `simulation.numeric.metric`, que prioriza `result.precise` e recua para o contrato legado. Os campos de resultado antigos continuam disponíveis; os cálculos intermediários e limiares não dependem mais de seus arredondamentos. `fingerprint` conserva a normalização por série histórica (AM-21 não foi corrigido), mas remove os pisos numéricos que distorciam entradas positivas pequenas; a referência zero recebe tratamento explícito.

## Correções delimitadas

1. `compare_results`: referência positiva menor que1e-9 deixa de ser tratada como zero. A referência exatamente zero conserva a convenção histórica de variação percentual0; não se inventa denominador. Resultado percentual não finito é rejeitado.
2. Goal compara TP e SLA precisos e calcula score com essas métricas. Não foram acrescentadas combinações de capacidade (AM-10 permanece). O score só é arredondado depois de ordenar.
3. Sensibilidade conserva ganhos marginais pequenos; Monte Carlo agrega os valores precisos de cada execução. Não foi alterado o tratamento de inviáveis (AM-09 permanece).
4. Recuperação usa métricas precisas e ordena o score antes de arredondar sua apresentação. A coluna `Makespan` conserva o contrato legado19,97h, com precisão completa no resultado aninhado. Fórmula, pesos, ações e temporalidade preservados.
5. `finance_lens`: custo de capacidade diário usa custo operacional preciso / horizonte real, sem piso0,01. Exige horizonte positivo; parâmetros e resultados não finitos são rejeitados; horas/dia negativas são rejeitadas. Horas/dia zero são permitidas. `product_ratio` evita intermediários não representáveis quando a resposta final é representável. Contribuição unitária negativa conserva a convenção anterior de contribuição incremental zero, sem alterar o modelo financeiro.

## Referências independentes dos testes

- Aumentar1e-12 para2e-12 corresponde a100%, em vez de0% pelo piso da comparação.
- Custo0,01/horizonte0,001 corresponde a10/h; custo0,04/horizonte0,002 corresponde a20/h. O custo incremental em8h é80, não8.
- SLA2/3 dos pedidos =66,666...%; meta66,68% não é cumprida, embora o valor visual66,7% pareça suficiente.
- TP1,0004 cumpre meta1,0002, apesar do valor visual arredondado1,0.
- Ganho marginal de1 para1,0004 é0,0004, preservado em sensibilidade.
- Estatísticas de quatro valores precisos iguais conservam a média precisa.
- Dois scores de recuperação que ambos aparecem0,0 são classificados pela diferença real antes de utilizar desempate de custo.

Comando executado:

`/workspace/work/audit/venv/bin/python -m pytest -q -p no:cacheprovider tests/test_am11_consumers.py`

Resultado: **19 aprovados**, em0,05s; um aviso externo de depreciação pytest/anyio. Também verificada sintaxe AST compatível com Python3.10 dos três módulos e do teste. Os19 integram a regressão final: não somar novamente ao total global.

## Inventário dos pisos e tolerâncias restantes

| Local | Significado e tratamento |
|---|---|
| `simulation/metrics.py:fingerprint` dois pisos0,01 | Removidos por distorção numérica: maxTP usa valores reais; TP de referência zero produz Fluxo0; custo-base zero produz eficiência100 quando o novo custo também ézero e0 quando épositivo. A normalização por série, achado AM-21, não mudou. |
| `simulation/innovation.py:stress_test`, `1/max(mean_tp,0.01)` | Escala limitadora do índice heurístico de fragilidade, não definição física de throughput. Fórmula preservada. |
| `atelier/decision_quality.py`, `EPS_COST=.01`, `EPS_H=.005`, `EPS_SLA=.005` | Tolerâncias explícitas de comparação das alternativas; não são pisos de denominador. Preservadas. |
| `simulation/response.py`, melhoria material>.005 | Critério econômico/operacional de decisão já existente. Preservado pelo responsável do motor. |
| `atelier/record_integrity.py`, `Decimal('0.01')` | Unidade monetária centesimal para conferir texto do registro, preservada. |
| `atelier/web/engineering_charts.js`, amplitude mínima.01 | Escala visual para eixo divergente; não modifica dados, preservada. |
| `atelier/web/app.js`, `min=0.01` no editor de roteiro | Restrição atual do controle visual, não substitui a entrada no cálculo; entrada JSON aceita menores positivos. Mantida para evitar mudança de fluxo não necessária à reprodução. |
| `simulation/engine_v26_legacy.py` pisos0,01 | Motor explicitamente arquivado; não é chamado pelo `start.py`/`atelier` atual. Não foi reescrito nesta etapa. A correção se aplica ao motor distribuído ativo. |

## Consumidores tratados pelo agente principal

`response.analyze_response`, `decision_lab.evaluate_decisions` e `atlas._status` também precisam usar precisão real. Em especial, os campos aditivos `completion_h`/`lateness_h` são necessários para não reconstituir prioridade crítica a partir de conclusões arredondadas. Essas observações foram comunicadas ao agente principal antes da implementação e não foram editadas nesta revisão.


Complemento final: mais três testes verificam fluxo normalizado50% com TP1e-6/2e-6, custo relativo igual1 em5e-6/5e-6 (eficiência58 pela fórmula existente), referências zero explícitas e pontuação Murphy usando utilização precisa do posto. Os19 testes focais passaram após esses ajustes.
