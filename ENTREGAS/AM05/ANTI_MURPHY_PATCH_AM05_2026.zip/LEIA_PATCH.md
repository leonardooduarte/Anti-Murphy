# Patch AM05 sobre AM11

Se baixou o ZIP completo, nao precisa aplicar patch. Para reproduzir, extraia uma copia limpa do ZIP AM11, sem executar primeiro. Nao use uma instalacao com dados locais editados como unica copia.

```text
python APLICAR_PATCH_AM05.py "C:\Projetos\baseAM11\ANTI_MURPHY_FINAL_2026" "C:\Projetos\AntiMurphyAM05"
```

A origem nunca e sobrescrita. O destino precisa ser novo e fora da origem. O script confere hashes de todos os353arquivos da base, valida overlay, copia para destino novo e confere alvo. Fonte de referencia: commit4cc48a4f32045278b2fc520bfa8e022419f26cfc. O diff textual acompanha o overlay que inclui screenshots binarios. Nao remova seus backups ou a versao AM11.
