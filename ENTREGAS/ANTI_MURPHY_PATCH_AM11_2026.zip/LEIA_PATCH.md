# Patch AM11-2026.1

O ZIP completo ja contem as correcoes; este patch e alternativa reproduzivel.
Extraia a base AM01-AM06 em pasta NOVA e NAO a execute antes de aplicar o patch.

```text
python APLICAR_PATCH_AM11.py "C:\projetos\base\ANTI_MURPHY_FINAL_2026" "C:\projetos\ANTI_MURPHY_AM11"
```

A base nunca e sobrescrita. O script verifica hashes de todos os arquivos-base recebidos e cria nova pasta, aplicando o overlay verificado. Se voce editou projetos locais, mantenha-os em backup e use uma extracao limpa para aplicar. AM11.patch serve para revisao textual; o overlay tambem inclui a evidencia binaria. Manifesto contem hashes-base e alvo. Nenhum patch em AM05 ou demais achados foi aplicado.
