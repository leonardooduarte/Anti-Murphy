# Patch AM19 sobre o ZIP visual recebido

Extraia uma base limpa de ANTI_MURPHY_EVOLUCAO_VISUAL_02_COMPLETO.zip,
sem executar. Rode `python APLICAR_PATCH_AM19.py "base/ANTI_MURPHY_FINAL_2026" "nova_pasta_AM19"`.
O aplicador verifica os hashes e cria uma pasta nova; não altera a origem.
Uma extração apenas da AM15 não é base suficiente: faltam as mudanças visuais.
O ZIP inclui o overlay de documentos e evidências binárias; AM19.patch é a
representação textual para revisão. Se baixou o aplicativo completo, não
precisa aplicar este patch. O ZIP-base recebido também acompanha a entrega.
