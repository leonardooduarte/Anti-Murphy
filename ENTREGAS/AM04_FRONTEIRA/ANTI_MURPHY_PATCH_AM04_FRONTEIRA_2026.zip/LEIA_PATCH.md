# Patch do complemento AM04 sobre AM10

Base: extração limpa do ZIP AM10, commit 9768344.
Execute: `python APLICAR_PATCH_AM04_FRONTEIRA.py "pasta_base/ANTI_MURPHY_FINAL_2026" "nova_pasta"`.
O aplicador verifica todos os hashes e cria uma pasta nova. Não altera a base.
O arquivo .patch é a representação textual; o ZIP também contém o overlay
com as imagens e evidências binárias necessárias à reprodução integral.
Se baixou o ZIP completo, não precisa aplicar este patch.
