"""Apply optional-priority correction to a fresh AM19 extraction, always creating a NEW folder."""
from pathlib import Path
import argparse,hashlib,json,shutil,sys

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('base',type=Path);parser.add_argument('output',type=Path)
 args=parser.parse_args();source=args.base.resolve();target=args.output.resolve();root=Path(__file__).resolve().parent
 manifest=json.loads((root/'manifest.json').read_text('utf-8'))
 if source==target or source in target.parents or target.exists():
  parser.error('Escolha uma pasta NOVA fora da base; nada foi alterado.')
 for name,expected in manifest['base_files'].items():
  p=source/name
  if not p.is_file() or digest(p)!=expected:parser.error('Base diferente da extracao original em '+name+'; nada foi alterado.')
 for name in manifest['added']:
  if (source/name).exists():parser.error('Arquivo novo ja existe na base: '+name)
 for name in manifest['changed']+manifest['added']:
  p=root/'arquivos'/name
  if not p.is_file() or digest(p)!=manifest['target_files'][name]:parser.error('Patch incompleto/corrompido: '+name)
 shutil.copytree(source,target)
 for name in manifest['changed']+manifest['added']:
  dest=target/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(root/'arquivos'/name,dest)
 for name,expected in manifest['target_files'].items():
  if digest(target/name)!=expected:raise RuntimeError('Falha na verificacao de '+name)
 print('PRIORIDADE aplicado e verificado. Base original preservada. Nova pasta:',target)
if __name__=='__main__':main()
